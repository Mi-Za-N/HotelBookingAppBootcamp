import axios from 'axios';
export default axios.create(
    { baseURL:"http://pascal-enigma.site:9003/"}
)