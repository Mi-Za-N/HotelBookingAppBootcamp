// @flow

export default () => {
  const spinnerTheme = {
    height: 80
  };

  return spinnerTheme;
};
